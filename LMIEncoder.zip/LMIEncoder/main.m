//
//  main.m
//  LedMatrixImage
//
//  Created by Jonatan Yde on 06/12/2017.
//  Copyright © 2017 Codeninja. All rights reserved.
//

#import <AppKit/AppKit.h>
#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, ColorSpace)
{
    rgb888,
    rgb565
};


void displayInfo(NSString *file)
{
    NSData *data = [NSData dataWithContentsOfFile: file];
    const unsigned char *bytes = [data bytes];
                
    //Header [LMI][0=rgb888,1=rgb565][width in hex][height in hex][data]
    int headerSize = 8;
    float width, height;
    ColorSpace colorSpace = (int)bytes[3] ;
    width = bytes[4] << 8 |  bytes[5] ;
    height = bytes[6] << 8 |  bytes[7] ;
    BOOL isMultiFrame = NO;
    
    
    int index = headerSize;
    int frameLength = (width*height) * (colorSpace == rgb565 ? 2 : 4);
    index += frameLength;
    
    if(data.length-1 > index+frameLength  )
        isMultiFrame = YES;

    printf("Printing information about: %s\n", [file cStringUsingEncoding:NSASCIIStringEncoding ]);
    printf("Width: %i\n", (int)width);
    printf("Height: %i\n", (int)height);
    printf("Colorspace: %s\n", (colorSpace == rgb565 ? "rgb565" : "rgb888"));
    printf("Frames: %i\n", (isMultiFrame ? 99 : 1));
}

int main(int argc, char * argv[]) {
    @autoreleasepool {
        
        /*
        uint8_t in_char[2] = {0xB5, 0x56};
        uint16_t out_rgb565  = ((uint16_t) in_char[0] << 8) | in_char[1];
        */
        
        
        //bool condensed_output = true;
        
        
        NSString *inputFile = @"";
        NSString *outputName;
        bool isRGB565 = false;
        int width = 0, height = 0;
        bool input_is_encoded = NO;

        char c;
        while ((c = getopt (argc, argv, "i:o:r")) != -1)
            switch (c)
        {
            case 'i':
                inputFile = [NSString stringWithFormat:@"%s", optarg];
                if([inputFile.pathExtension.lowercaseString isEqualToString:@"lmi"])
                    input_is_encoded = YES;
                break;
            case 'o':
                outputName = [NSString stringWithFormat:@"%s", optarg];
                if( [outputName pathExtension].length !=0 )
                    outputName = [outputName stringByDeletingPathExtension];
                break;
            case 'r':
                isRGB565 = YES;
                break;
            case '?':
                if (optopt == 'i' )
                    fprintf (stderr, "Option -%c requires an argument.\n", optopt);
                else if (isprint (optopt))
                    fprintf (stderr, "Unknown option `-%c'.\n", optopt);
                else
                    fprintf (stderr,
                             "Unknown option character `\\x%x'.\n",
                             optopt);
                return 1;
            default:
                abort ();
        }
        
        if( [inputFile isEqualToString:@""] )
        {
            printf("Usage: lmiencoder -i <file> [-o <file>] [-r(gb565)].\n");
            return 1;
        }
        
        if(input_is_encoded)
        {
            displayInfo(inputFile);
            return 0;
        }
        
        if(!outputName)
            outputName = [[inputFile stringByDeletingPathExtension] lastPathComponent];
        
        NSImage *inputImage = [[NSImage alloc] initWithContentsOfFile:inputFile];
        NSBitmapImageRep *inputRep = [NSBitmapImageRep imageRepWithData:[inputImage TIFFRepresentation]];
        
        width = inputImage.size.width;
        height = inputImage.size.height;
        
        //Byte array to hold image data
        NSMutableData *byteArray = [[NSMutableData alloc]initWithCapacity:0 ];
        
        //Construct 4 bytes long header
        uint8_t header[4] =  {'L', 'M', 'I', (isRGB565 ? 0x01 : 0x00)};
        
        [byteArray appendBytes: &header length: sizeof(header)];
        
        //Append 2+2 bytes dimension values width & height
        unsigned char _width[2];
        _width[0] = (width >> 8) & 0xFF;
        _width[1] = width & 0xFF;
        
        unsigned char _height[2];
        _height[0] = (height >> 8) & 0xFF;
        _height[1] = height & 0xFF;
        
        [byteArray appendBytes:&_width length:2];
        [byteArray appendBytes:&_height length:2];
        
        
        for(int y = 0; y < height; y++)
        {
            for(int x = 0; x < width; x++)
            {
                unsigned char currentRedByte, currentBlueByte, currentGreenByte, currentAlphaByte = 0x00;
                uint16_t c_rgb565 = 0;
                
                //Get current color
                NSColor *color = [inputRep colorAtX:x y:y];
                
                //32-bit RGBA values
                currentRedByte = lroundf([color redComponent] * 255);
                currentGreenByte = lroundf([color greenComponent] * 255);
                currentBlueByte = lroundf([color blueComponent] * 255);
                currentAlphaByte = lroundf([color alphaComponent] * 255);
                
                //16-bit RGB values
                c_rgb565 = (currentRedByte & 0b11111000) << 8;
                c_rgb565 = c_rgb565 + ((currentGreenByte & 0b11111100) << 3);
                c_rgb565 = c_rgb565 + ((currentBlueByte) >> 3);
                c_rgb565 = (c_rgb565>>8) | ((c_rgb565 & 0xff) << 8); //Reverse order of bytes
                
                //Append byte to array
                if(isRGB565)
                {
                    [byteArray appendBytes:&c_rgb565 length:sizeof(c_rgb565)];
                }
                else
                {
                    [byteArray appendBytes:&currentRedByte length:sizeof(currentRedByte)];
                    [byteArray appendBytes:&currentGreenByte length:sizeof(currentGreenByte)];
                    [byteArray appendBytes:&currentBlueByte length:sizeof(currentBlueByte)];
                    [byteArray appendBytes:&currentAlphaByte length:sizeof(currentAlphaByte)];
                }
            }
        }
        [byteArray writeToFile: [outputName stringByAppendingPathExtension:@"lmi"] atomically:YES];
        
    }
    return 0;
}
